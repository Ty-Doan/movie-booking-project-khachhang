export const GET_USER_INFOR = "Get user information";
export const GET_MOVIE_INFOR_BY_THEATER =
  "Get movie information by theater to show in tab";
export const GET_MOVIE_INFOR =
  "Get movie information to show in buy ticket page";
export const SHOW_SPINNER = "Show spinner page";
export const HIDE_SPINNER = "Hide spinner page";
